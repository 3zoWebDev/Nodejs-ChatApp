const express = require("express");
const mongoose = require("mongoose");
const expressLayouts = require("express-ejs-layouts");
const passport = require('passport');
const flash = require('connect-flash');
const session = require('express-session');
const methodoverride = require("method-override");
const PORT = process.env.PORT || 3000;
const app = express();
app.use(expressLayouts);
app.set("view engine" ,"ejs");

//Express body parser
app.use(express.urlencoded({ extended: true }));

// Express session
app.use(
    session({
      secret: "SECRET",
      resave: true,
      saveUninitialized: true
    })
  );

  // Passport middleware
  app.use(passport.initialize());
  app.use(passport.session());

  // Connect flash
  app.use(flash());

  app.use(methodoverride("_method"));

  // Global variables
  app.use(function(req, res, next) {
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    res.locals.error = req.flash('error');
    next();
  });


//look for static files here(CSS, JS, Image, video, audio)
app.use(express.static("public"));

/// Routes
app.use("/" , require('./routes/index'))
app.use("/users" , require('./routes/users'))
const { ensureAuthenticated, forwardAuthenticated } = require('./config/auth');
// Passport Config
require('./config/passport')(passport);


const server = app.listen(PORT);
const io = require('socket.io').listen(server);


 /************************************************** */
 const rooms = {}

 app.get('/dashboard/mychat', ensureAuthenticated ,(req, res) => {
    //console.log(req.user)
   res.render('./chatApp/chatroomindex', { rooms: rooms  })
 })

 app.post('/dashboard/mychat/room', ensureAuthenticated , (req, res) => {
      // console.log(req.body)
   if (rooms[req.body.room] != null) {
     return res.redirect('/dashboard')
   }
   rooms[req.body.room] = { users: {} }
   res.redirect(req.body.room)
  // Send message that new room was created

   io.emit('room-created', req.body.room)
 });


 app.get('/dashboard/mychat/:room', ensureAuthenticated , (req, res) => {
     res.render('./chatApp/room', { roomName: req.params.room , user:req.user })
 })


 io.on('connection', socket => {
   socket.on('new-user', (room, name) => {
     socket.join(room)
     rooms[room].users[socket.id] = name
     socket.to(room).broadcast.emit('user-connected', name)
   })
   socket.on('send-chat-message', (room, message,img , name) => {
     socket.to(room).broadcast.emit('chat-message', { message: message, name: rooms[room].users[socket.id] , img:img , name:name})
   })
   socket.on('disconnect', () => {
     getUserRooms(socket).forEach(room => {
       socket.to(room).broadcast.emit('user-disconnected', rooms[room].users[socket.id])
       delete rooms[room].users[socket.id]
     })
   })
 })

 function getUserRooms(socket) {
   return Object.entries(rooms).reduce((names, [name, room]) => {
     if (room.users[socket.id] != null) names.push(name)
     return names
   }, [])
 }

//Connect to MongoDb
mongoose.connect(
    process.env.DB,
    { useNewUrlParser: true, useUnifiedTopology: true },
    () => {
      console.log("mongodb connected!");
    }
  );

