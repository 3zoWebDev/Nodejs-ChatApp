const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");
const passport = require('passport');
const { forwardAuthenticated ,ensureAuthenticated} = require('../config/auth');


//User Model
const User = require("../models/User")



// GET Login Route
router.get("/login", (req,res)=>{
    res.render("login");
});

// POST Login Page

router.post('/login', (req, res, next) => {
    passport.authenticate('local', {
      successRedirect: '/dashboard',
      failureRedirect: '/users/login',
      failureFlash: true
    })(req, res, next);
  });

// Logout
router.get('/logout', (req, res) => {
    req.logout();
    req.flash('success_msg', 'You are logged out');
    res.redirect('/users/login');
  });


//GET Register Page
router.get("/register", (req,res)=>{
    res.render("register");
});

//POST Register Page
router.post("/register", (req,res)=>{
    const { name, email, password, password2 } = req.body;
    let errors = [];
    // check for required fields
    if (!name || !email || !password || !password2) {
      errors.push({ msg: 'Please enter all fields' });
    }

    // check if password matched
    if (password != password2) {
      errors.push({ msg: 'Passwords do not match' });
    }

    // check if passwords at least 6 char
    if (password.length < 6) {
      errors.push({ msg: 'Password must be at least 6 characters' });
    }

    // if err array has thig
    if (errors.length > 0) {
      res.render('register', {
        errors,
        name,
        email,
        password,
        password2
      });
    }else {
        // Validation  Passed
    User.findOne({email:email}).then(
        user => {
            if(user){
                //if User Exists
                errors.push({msg: "Email is Already registerd"})
                res.render('register', {
                    errors,
                    name,
                    email,
                    password,
                    password2
                  });
            }else {
                const newUser = new User({
                    name,
                    email,
                    password
                  });

                  bcrypt.genSalt(10, (err, salt) => {
                    bcrypt.hash(newUser.password, salt, (err, hash) => {
                      if (err) throw err;
                      newUser.password = hash;
                      newUser
                        .save()
                        .then(user => {
                          req.flash(
                            'success_msg',
                            'You are now registered and can log in'
                          );

                          res.redirect('/users/login');
                        })
                .catch(err => console.log(err))
            });
        });
      }
    });
  }

});

//changePassword Route
router.get("/:id/changePassword" , (req,res)=>{
  //User.fin
 // res.render("changePassword");
 User.findById(req.params.id, (err,user)=>{
   if(err){
     console.log(err);
   }else {
     res.render("changePassword", {user});
   }

 })
});
router.put("/:id/changePassword", (request, response) => {
  var newPassword = bcrypt.hashSync(request.body.password, 10)
  let user = request.user
    user.password = newPassword
   User.findByIdAndUpdate(request.user._id,user).then(user => {
  response.redirect("/dashboard");
  });
  });
router.get("/profile", ensureAuthenticated,(request, response) => {
  // console.log(request.user);
//   Author.find({_id: request.params.id })
User.findById(request.user._id).then(user => {
  //{author: author} || {author}
  response.render("profile", { user });
});
});
router.get("/profile/edit", ensureAuthenticated,(request, response) => {
// console.log(request.user);
//   Author.find({_id: request.params.id })
    User.findById(request.user._id).then(user => {
    response.render("edit", { user });
    });
});
router.put("/profile/edit", (request, response) => {

var newUser = request.user
// let b = request.body
//  let finalUser = {...newUser._doc,...request.body}
//  console.log(finalUser)
newUser.name = request.body.name || newUser.name
newUser.bio = request.body.bio || newUser.bio
newUser.image = request.body.image || newUser.image
newUser.profileStatus = true
User.findByIdAndUpdate(request.user._id,newUser).then(user => {
console.log(user);
response.redirect("/users/profile");
});
});


// router.put("/:id", (req,res)=>{
// //   let user = new User(req.body);
//   //  const { oldpassword, newpassword } = req.body;
//   //  let errors = [];
//   //  // check for required fields
//   //  if (!oldpassword || !newpassword) {
//   //    errors.push({ msg: 'Please enter all fields' });
//   //      }

//   // //  if err array has thing
//   //  if (errors.length > 0) {
//   //    res.render('changePassword', {
//   //      errors,
//   //      oldpassword,
//   //      newpassword
//   //    });
//   //  }
//     //let newpass = req.body.user.password;

//      User.findByIdAndUpdate(req.params.id , req.body.user, (err , newpass)=>{
//         if(err) {
//           console.log(err)
//           bcrypt.genSalt(10, (err, salt) => {
//             bcrypt.hash(req.body.user.password, salt, (err, hash) => {
//               if (err) throw err;
//               req.body.user.password = hash;
//               req.body.user
//                 .save()
//                 .then(user => {
//                   req.flash(
//                     'success_msg',
//                     'You are Updated YourPassword Please log in'
//                   );
//                   res.redirect('/users/login');
//                 })
//         .catch(err => console.log(err))
//     });
// });
//     }
//     });
//     //console.log(newpass);



// //console.log(req.body.newpassword)

//  ////////////////////////////////////////////////////////////////////////
// //   // }else {
// //   //     // Validation  Passed
// //   // User.findOne({password:oldpassword})
// //   // .then(pass => {
// //   //         if(pass){
// //   //             //if oldpasswords matched already passwords
// //   //           // User.password = req.body.newpassword;
// //   //             User.findOneAndUpdate(password,newpassword);
// //   //             res.render("dashboard")
// //   //           }else{
// //   //             console.log("err")
// //   //           }
// //   //       })
// //   //       .catch(err => console.log(err));
// //   //     }

// //    //console.log(oldpassword +"    "  + newpassword);
//    });


module.exports = router;