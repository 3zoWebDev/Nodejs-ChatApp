const express = require("express");
const router = express.Router();
const { ensureAuthenticated, forwardAuthenticated } = require('../config/auth');


//User Model
const User = require("../models/User");

router.get("/", (req,res)=>{
  res.render("welcome");
});





// Dashboard
router.get('/dashboard', ensureAuthenticated, (req, res) =>{
  if(req.user.profileStatus){
  res.render('dashboard', {
  user: req.user
    })}else{
  res.redirect("/users/profile/edit")
  }
  });

module.exports = router;